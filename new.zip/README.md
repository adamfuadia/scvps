# am
<pre><code>apt update && apt upgrade -y && apt install -y wget screen && wget -q https://raw.githubusercontent.com/apih46/mini/main/setup.sh && chmod +x setup.sh && screen -S setup ./setup.sh</code></pre>
